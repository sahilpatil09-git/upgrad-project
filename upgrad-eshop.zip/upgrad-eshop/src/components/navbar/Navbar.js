
import React from "react";
import { AppBar, Toolbar, Typography, Button, InputBase } from "@mui/material";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link, useNavigate } from "react-router-dom";
import "./Navbar.css";
import { logout, getToken, getUser } from "../../common/AuthService";

export default function Navbar() {
  const navigate = useNavigate();
  const token = getToken();
  const user = getUser();
  const isAdmin = user && user.role && user.role.includes("ADMIN");

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <AppBar position="static" color="primary">
      <Toolbar className="nav-toolbar" style={{display:"flex", justifyContent:"space-between"}}>
        <div style={{display:"flex", alignItems:"center", gap:8}}>
          <ShoppingCartIcon />
          <Typography variant="h6">upGrad Eshop</Typography>
        </div>
        <div style={{display:"flex", alignItems:"center", gap:8}}>
          {!token ? (
            <>
              <Button color="inherit" component={Link} to="/login">Login</Button>
              <Button color="inherit" component={Link} to="/signup">Signup</Button>
            </>
          ) : (
            <>
              <InputBase placeholder="Search products..." className="search-bar" />
              <Button color="inherit" component={Link} to="/">Home</Button>
              {isAdmin && <Button color="inherit" component={Link} to="/add-product">Add Products</Button>}
              <Button color="inherit" onClick={handleLogout}>Logout</Button>
            </>
          )}
        </div>
      </Toolbar>
    </AppBar>
  );
}
