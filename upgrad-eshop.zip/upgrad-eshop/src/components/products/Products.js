
import React, { useEffect, useState } from "react";
import axios from "axios";
import { API_BASE_URL } from "../../common/Api";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(()=> {
    const fetchProducts = async () => {
      try {
        const resp = await axios.get(`${API_BASE_URL}/products`);
        setProducts(resp.data || []);
      } catch (err) {
        console.error(err);
        alert("Could not fetch products. Check API availability.");
      }
    };
    fetchProducts();
  }, []);

  const filtered = products.filter(p => p.name && p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={{padding:20}}>
      <h2>Products</h2>
      <input placeholder="Filter by name..." value={search} onChange={e=>setSearch(e.target.value)} style={{padding:8, marginBottom:12}} />
      <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))", gap:12}}>
        {filtered.map(p => (
          <div key={p.id || p._id} style={{border:"1px solid #ddd", padding:12, borderRadius:6}}>
            <h3>{p.name}</h3>
            <p>Price: ₹{p.price}</p>
            <p>{p.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
