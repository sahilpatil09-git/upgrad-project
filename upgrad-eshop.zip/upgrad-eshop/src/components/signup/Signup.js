
import React, { useState } from "react";
import { signup } from "../../common/AuthService";
import "./Signup.css";

export default function Signup() {
  const [form, setForm] = useState({ email: "", password: "", firstName: "", lastName: "", contactNumber: "" });

  const handleChange = (e) => setForm({...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await signup(form);
      alert("Signup successful. Please login.");
    } catch (err) {
      alert("Signup failed. Check console for details.");
      console.error(err);
    }
  };

  return (
    <div className="signup-container">
      <h2>Sign Up</h2>
      <form onSubmit={handleSubmit}>
        <input name="firstName" placeholder="First Name" onChange={handleChange} required />
        <input name="lastName" placeholder="Last Name" onChange={handleChange} required />
        <input name="email" type="email" placeholder="Email" onChange={handleChange} required />
        <input name="password" type="password" placeholder="Password" onChange={handleChange} required />
        <input name="contactNumber" placeholder="Contact Number" onChange={handleChange} required />
        <button type="submit">Sign Up</button>
      </form>
    </div>
  );
}
