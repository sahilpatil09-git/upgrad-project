
import axios from "axios";
import { API_BASE_URL } from "./Api";

export const login = async (username, password) => {
  const response = await axios.post(`${API_BASE_URL}/auth/signin`, { username, password });
  const token = response.headers["x-auth-token"];
  if (token) localStorage.setItem("token", token);
  // store some user info if present in body
  if (response.data) localStorage.setItem("user", JSON.stringify(response.data));
  return response;
};

export const signup = (userData) => {
  return axios.post(`${API_BASE_URL}/auth/signup`, userData);
};

export const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
};

export const getToken = () => localStorage.getItem("token");
export const getUser = () => {
  const u = localStorage.getItem("user");
  return u ? JSON.parse(u) : null;
};
