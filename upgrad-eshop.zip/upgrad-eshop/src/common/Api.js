export const API_BASE_URL = "https://dev-project-ecommerce.upgrad.dev/api";
