
# upgrad-eshop (skeleton)

This is a minimal runnable React frontend skeleton for the UpGrad Eshop project.
It follows the folder & file rules given in the project instructions.

## How to run

1. Extract the zip.
2. In project root run:
   ```bash
   npm install
   npm start
   ```
3. The app starts on http://localhost:3000 and uses API base:
   https://dev-project-ecommerce.upgrad.dev/api

Note: This is a frontend skeleton (create-react-app-like). To fully run
you need `react-scripts` available (install via `npm install react-scripts` if needed).
